def ajoute_deux(v):
	return v + 2