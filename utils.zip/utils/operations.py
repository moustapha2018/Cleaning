def ajoute_deu(v):
	return v - 2
